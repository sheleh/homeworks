#lesson_#1
# using print()
print('hello world!')
print('hello world!'*5, sep = '_')
print('hello world!','hello sun!','hello moon!' ,sep = '#')
print('hello world!', 'hello sun!', 'hello moon', sep='\n++++++++++\n', 
      end = '\n\t======THE END======')